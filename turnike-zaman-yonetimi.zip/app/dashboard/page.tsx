export default function DashboardPage() {
  return (
    <main style={{ padding: 24, maxWidth: 800 }}>
      <h1 style={{ fontSize: 24, fontWeight: 700 }}>Dashboard</h1>
      <p style={{ marginTop: 8, color: "#666" }}>V1 hızlı navigasyon</p>

      <ul style={{ marginTop: 16, lineHeight: 2 }}>
        <li><a href="/policy">/policy</a></li>
        <li><a href="/employees">/employees</a></li>
        <li><a href="/events">/events</a></li>
        <li><a href="/reports/daily">/reports/daily</a></li>
        <li><a href="/reports/monthly">/reports/monthly</a></li>
      </ul>
    </main>
  );
}
