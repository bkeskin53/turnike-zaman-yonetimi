import DailyReportClient from "./ui";

export default function DailyReportPage() {
  return (
    <main style={{ padding: 24, maxWidth: 1100 }}>
      <h1 style={{ fontSize: 24, fontWeight: 700 }}>Daily Report</h1>
      <p style={{ marginTop: 8, color: "#666" }}>
        Önce “Recompute” yap, sonra listeyi gör. (Yetki: ADMIN/HR)
      </p>
      <div style={{ marginTop: 16 }}>
        <DailyReportClient />
      </div>
    </main>
  );
}
