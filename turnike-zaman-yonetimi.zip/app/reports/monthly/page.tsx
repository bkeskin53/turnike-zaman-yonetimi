import MonthlyReportClient from "./ui";

export default function MonthlyReportPage() {
  return (
    <main style={{ padding: 24, maxWidth: 1100 }}>
      <h1 style={{ fontSize: 24, fontWeight: 700 }}>Monthly Report</h1>
      <p style={{ marginTop: 8, color: "#666" }}>
        Bu rapor, daha önce recompute edilmiş DailyAttendance kayıtlarını toplar. (Yetki: ADMIN/HR)
      </p>
      <div style={{ marginTop: 16 }}>
        <MonthlyReportClient />
      </div>
    </main>
  );
}
