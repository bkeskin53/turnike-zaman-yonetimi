import CompanySettingsClient from "./ui";

export default function CompanyPage() {
  return (
    <main style={{ padding: 24, maxWidth: 800 }}>
      <h1 style={{ fontSize: 24, fontWeight: 700 }}>Company & Policy</h1>
      <p style={{ marginTop: 8, color: "#666" }}>
        Bu sayfa Company ve CompanyPolicy ayarlarını yönetir. (Yetki: ADMIN/HR)
      </p>
      <div style={{ marginTop: 16 }}>
        <CompanySettingsClient />
      </div>
    </main>
  );
}
