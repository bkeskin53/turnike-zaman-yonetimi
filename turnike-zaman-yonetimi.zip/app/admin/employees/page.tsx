import EmployeesClient from "./ui";

export default function EmployeesPage() {
  return (
    <main style={{ padding: 24, maxWidth: 1000 }}>
      <h1 style={{ fontSize: 24, fontWeight: 700 }}>Employees</h1>
      <p style={{ marginTop: 8, color: "#666" }}>
        Çalışan listesi ve yönetimi. (Yetki: ADMIN/HR)
      </p>

      <div style={{ marginTop: 16 }}>
        <EmployeesClient />
      </div>
    </main>
  );
}
