import EventsClient from "./ui";

export default function EventsPage() {
  return (
    <main style={{ padding: 24, maxWidth: 1100 }}>
      <h1 style={{ fontSize: 24, fontWeight: 700 }}>Events (Manual IN/OUT)</h1>
      <p style={{ marginTop: 8, color: "#666" }}>
        Manuel RawEvent girişi ve listeleme. (Yetki: ADMIN/HR)
      </p>

      <div style={{ marginTop: 16 }}>
        <EventsClient />
      </div>
    </main>
  );
}
